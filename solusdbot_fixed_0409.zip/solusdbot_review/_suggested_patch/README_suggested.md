# SOLUSDBOT – Suggested Improvements

This folder contains suggested scaffolding to make the project easier to run locally and in GitHub Actions.

## What’s included
- `requirements.txt` – minimal deps, adjust after verifying imports.
- `.env.example` – template for secrets (use GitHub *Secrets* in CI).
- `config.example.yaml` – copy to `config.yaml` for runtime parameters.
- `.github/workflows/solusdbot-cron.yml` – schedule + manual run.

## Secrets
- `PIONEX_API_KEY` / `PIONEX_API_SECRET`: API credentials (store as GitHub secrets).
- `DASHBOARD_TOKEN`: token used by your HTML/metrics dashboard. In CI, it is injected via env so you must reference `os.environ["DASHBOARD_TOKEN"]` in code or replace the `__DASHBOARD_TOKEN__` placeholder at build time.

## Local run
```bash
cp .env.example .env   # and fill values
cp config.example.yaml config.yaml
pip install -r requirements.txt
python SOLUSDBOT-main/selftest.py
python SOLUSDBOT-main/main.py
```
